# KITCHOL Grocery — Android starter project

Configured for:
- Android app
- Own grocery shop / local delivery
- Delivery area: Ichapur, Kolkata
- English + Bengali toggle
- Cash on Delivery demo checkout
- Online payment option shown as not yet integrated

## Open in Android Studio
1. Download and extract this ZIP.
2. Open the `KITCHOL_Grocery_Android` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK 35 if prompted.
4. Run the `app` configuration on an emulator or Android phone.

## Important before real customer launch
This is a starter/demo project, not a production-ready store:
- Product names and prices are sample data. Replace them with your real inventory and prices.
- Orders currently stay inside the demo app; no server/admin notification is connected.
- Online payment is not integrated. Add a payment provider and secure backend before accepting payments.
- Add customer phone/name, order database, admin dashboard, delivery fee rules, privacy policy and production testing.
- Do not publish until order handling and payment flows are tested.

Package: `com.kitchol.grocery`
