package com.kitchol.grocery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF16834B)
private val Pale = Color(0xFFF3F8F4)

data class GroceryProduct(val id: Int, val nameEn: String, val nameBn: String, val category: String, val price: Int, val unit: String, val emoji: String)
private val products = listOf(
    GroceryProduct(1, "Rice", "চাল", "Staples", 65, "1 kg", "🍚"),
    GroceryProduct(2, "Sunflower Oil", "সূর্যমুখী তেল", "Oil", 145, "1 L", "🫗"),
    GroceryProduct(3, "Tomato", "টমেটো", "Vegetables", 40, "1 kg", "🍅"),
    GroceryProduct(4, "Sugar", "চিনি", "Staples", 48, "1 kg", "🍬"),
    GroceryProduct(5, "Potato", "আলু", "Vegetables", 30, "1 kg", "🥔"),
    GroceryProduct(6, "Milk", "দুধ", "Dairy",  treinta(), "500 ml", "🥛")
)
private fun treinta() = 32

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KitcholApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitcholApp() {
    var bengali by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(mapOf<Int, Int>()) }
    var page by remember { mutableStateOf("home") }
    var address by remember { mutableStateOf("Ichapur, Kolkata") }
    var payment by remember { mutableStateOf("COD") }
    var orderPlaced by remember { mutableStateOf(false) }
    val total = products.sumOf { p -> p.price * (cart[p.id] ?: 0) }
    val visible = products.filter {
        val q = search.trim()
        q.isEmpty() || it.nameEn.contains(q, true) || it.nameBn.contains(q)
    }
    val title = if (bengali) "KITCHOL গ্রোসারি" else "KITCHOL Grocery"

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Green, background = Pale)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text(title, fontWeight = FontWeight.Bold, color = Green)
                        Text(if (bengali) "আপনার বাড়িতে তাজা বাজার" else "Fresh groceries at your door", fontSize = 11.sp)
                    } },
                    actions = {
                        TextButton(onClick = { bengali = !bengali }) { Text(if (bengali) "EN" else "বাংলা") }
                        BadgedBox(badge = { if (cart.values.sum() > 0) Badge { Text(cart.values.sum().toString()) } }) {
                            IconButton(onClick = { page = "cart" }) { Icon(Icons.Default.ShoppingCart, "Cart") }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(if (bengali) "হোম" else "Home") })
                    NavigationBarItem(selected = page == "cart", onClick = { page = "cart" }, icon = { Icon(Icons.Default.ShoppingCart, null) }, label = { Text(if (bengali) "কার্ট" else "Cart") })
                    NavigationBarItem(selected = page == "account", onClick = { page = "account" }, icon = { Icon(Icons.Default.Person, null) }, label = { Text(if (bengali) "অ্যাকাউন্ট" else "Account") })
                }
            }
        ) { pad ->
            when (page) {
                "home" -> LazyColumn(Modifier.padding(pad).fillMaxSize().background(Pale).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text(if (bengali) "ডেলিভারি লোকেশন" else "DELIVERY LOCATION", color = Color.White, fontSize = 11.sp)
                                Text("📍 $address", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(if (bengali) "আজই আপনার পছন্দের বাজার অর্ডার করুন" else "Order your daily essentials from your local shop", color = Color.White)
                            }
                        }
                    }
                    item {
                        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(if (bengali) "চাল, তেল, সবজি খুঁজুন..." else "Search rice, oil, vegetables...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                    }
                    item { Text(if (bengali) "জনপ্রিয় পণ্য" else "Popular groceries", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    items(visible) { p ->
                        ProductRow(p, bengali, cart[p.id] ?: 0,
                            onAdd = { cart = cart + (p.id to ((cart[p.id] ?: 0) + 1)) },
                            onRemove = { val n = (cart[p.id] ?: 0) - 1; cart = if (n <= 0) cart - p.id else cart + (p.id to n) })
                    }
                }
                "cart" -> Column(Modifier.padding(pad).fillMaxSize().background(Pale).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (bengali) "আপনার কার্ট" else "Your cart", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (cart.isEmpty()) Text(if (bengali) "আপনার কার্ট খালি" else "Your cart is empty")
                    products.filter { (cart[it.id] ?: 0) > 0 }.forEach { p ->
                        ProductRow(p, bengali, cart[p.id] ?: 0,
                            onAdd = { cart = cart + (p.id to ((cart[p.id] ?: 0) + 1)) },
                            onRemove = { val n = (cart[p.id] ?: 0) - 1; cart = if (n <= 0) cart - p.id else cart + (p.id to n) })
                    }
                    if (cart.isNotEmpty()) {
                        HorizontalDivider()
                        Text("${if (bengali) "মোট" else "Total"}: ₹$total", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
                        Button(onClick = { page = "checkout" }, modifier = Modifier.fillMaxWidth()) { Text(if (bengali) "চেকআউট" else "Proceed to checkout") }
                    }
                }
                "checkout" -> Column(Modifier.padding(pad).fillMaxSize().background(Pale).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(if (bengali) "অর্ডার সম্পূর্ণ করুন" else "Checkout", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = address, onValueChange = { address = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (bengali) "ডেলিভারি ঠিকানা" else "Delivery address") })
                    Text(if (bengali) "পেমেন্ট পদ্ধতি" else "Payment method", fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = payment == "COD", onClick = { payment = "COD" }); Text(if (bengali) "ক্যাশ অন ডেলিভারি" else "Cash on Delivery")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = payment == "Online", onClick = { payment = "Online" }); Text(if (bengali) "অনলাইন পেমেন্ট" else "Online payment")
                    }
                    if (payment == "Online") Text(if (bengali) "অনলাইন পেমেন্ট গেটওয়ে সংযুক্ত করা বাকি। আপাতত COD ব্যবহার করুন।" else "Online payment gateway is not connected yet. Use COD for live orders.", color = Color(0xFF9A5B00))
                    Text("${if (bengali) "অর্ডারের মোট" else "Order total"}: ₹$total", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Button(onClick = { if (payment == "COD") { orderPlaced = true; cart = emptyMap(); page = "success" } }, enabled = payment == "COD" && total > 0, modifier = Modifier.fillMaxWidth()) {
                        Text(if (bengali) "অর্ডার নিশ্চিত করুন (ডেমো)" else "Place COD order (demo)")
                    }
                }
                "success" -> Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(64.dp))
                    Text(if (bengali) "ডেমো অর্ডার তৈরি হয়েছে!" else "Demo order placed!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(if (bengali) "এটি এখনো আসল দোকানে পাঠানো হয়নি।" else "This demo order has not been sent to your shop.")
                    Button(onClick = { page = "home" }) { Text(if (bengali) "হোমে ফিরুন" else "Back to home") }
                }
                else -> Column(Modifier.padding(pad).fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (bengali) "আমার অ্যাকাউন্ট" else "My account", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("KITCHOL Grocery")
                    Text(if (bengali) "ডেলিভারি এলাকা: ইছাপুর, কলকাতা" else "Delivery area: Ichapur, Kolkata")
                    Text(if (bengali) "স্থানীয় দোকানের ডেলিভারি" else "Local shop delivery")
                }
            }
        }
    }
}

@Composable
fun ProductRow(p: GroceryProduct, bn: Boolean, count: Int, onAdd: () -> Unit, onRemove: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).background(Pale, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Text(p.emoji, fontSize = 30.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (bn) p.nameBn else p.nameEn, fontWeight = FontWeight.SemiBold)
                Text("${p.unit} • ₹${p.price}", color = Green, fontSize = 13.sp)
            }
            if (count == 0) {
                OutlinedButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(if (bn) "যোগ" else "ADD") }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onRemove) { Icon(Icons.Default.RemoveCircleOutline, null, tint = Green) }
                    Text(count.toString(), fontWeight = FontWeight.Bold)
                    IconButton(onClick = onAdd) { Icon(Icons.Default.AddCircle, null, tint = Green) }
                }
            }
        }
    }
}
